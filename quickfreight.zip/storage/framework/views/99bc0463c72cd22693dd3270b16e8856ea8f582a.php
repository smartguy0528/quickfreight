<h3>Quick Freight Enterprise</h3>
<p>Hello. <?php echo e($carrier_name); ?>!</p>
<p>We're glad to let you know we will use your service.</p>
<p>Please log in our site and check the quote.</p>
<a href = "<?php echo e(route('login.carrier')); ?>">Quick Freight Enterprise Inc Service</a>
<p>US DOT Number: <?php echo e($carrier_dot_number); ?></p>
<p>Verify Code: <?php echo e($verify_code); ?></p>
<br>
<small>QUICK FREIGHT ENTERPRISE</small><br>
<small>15867 SW 147th LN</small><br>
<small>MIAMI, FL 33196</small><br>
<small>+1 786 208 9900</small>
<?php /**PATH /home3/yojae/public_html/resources/views/mail/carrier_send_quote.blade.php ENDPATH**/ ?>