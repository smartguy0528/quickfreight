<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Quote Details</h1>
        <ol class="breadcrumb mb-4">
            <?php if($quoteReq->status <= 12): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.all.quotes')); ?>">Quotes</a></li>
            <?php elseif($quoteReq->status == 13): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quote.invoices')); ?>">Completed Quotes</a></li>
            <?php endif; ?>

            <?php if($quoteReq->status == 1): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quotes.requested')); ?>">Requested Quotes</a></li>
            <?php elseif($quoteReq->status == 2): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quotes.checked')); ?>">Checked Quotes</a></li>
            <?php elseif($quoteReq->status == 3): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quotes.approved')); ?>">Approved Quotes</a></li>
            <?php elseif($quoteReq->status == 4): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quotes.rejected')); ?>">Rejected Quotes</a></li>
            <?php elseif($quoteReq->status == 5): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quotes.confirmed')); ?>">Confirmed Quotes</a></li>
            <?php elseif($quoteReq->status == 6): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quotes.submitted')); ?>">Submitted Quotes</a></li>
            <?php elseif($quoteReq->status == 7): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quotes.published')); ?>">Published Quotes</a></li>
            <?php elseif($quoteReq->status > 7 && $quoteReq->status < 12): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quotes.ongoing')); ?>">On going Quotes</a></li>
            <?php elseif($quoteReq->status == 12): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quotes.completed')); ?>">Completed Quotes</a></li>
            <?php endif; ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quote.details', $quoteReq->id)); ?>">Quote Details</a></li>
            <li class="breadcrumb-item active">Quote Details Edit</li>
        </ol>


        <div class="card mb-4">
            <div class="card-body table-responsive p-5 pt-3">
                
                <div class="text-end">
                    <a href="<?php echo e(route('manager.quote.details', $quoteReq->id)); ?>" class="btn btn-danger" title="Close"><i class="fas fa-times"></i></a>
                </div>
                <div class="d-flex">
                    <h3 class="text-primary my-2">
                        Quote ID: #<?php echo e($quoteReq->id_alias); ?>

                    </h3>
                    <div class="ms-2 mb-3">
                        <?php if($quoteReq->status == 1): ?>
                        <p class="badge bg-success">Status: Order Requested</p>
                        <?php elseif($quoteReq->status == 2): ?>
                        <p class="badge bg-success">Status: Order Accepted</p>
                        <?php elseif($quoteReq->status == 3): ?>
                        <p class="badge bg-success">Status: Order Approved</p>
                        <?php elseif($quoteReq->status == 4): ?>
                        <p class="badge bg-danger">Status: Order Rejected</p>
                        <?php elseif($quoteReq->status == 5): ?>
                        <p class="badge bg-success">Status: Carrier Selected</p>
                        <?php elseif($quoteReq->status == 6): ?>
                        <p class="badge bg-success">Status: Quote Sent to Carrier</p>
                        <?php elseif($quoteReq->status == 7): ?>
                        <p class="badge bg-success">Status: Quote Published</p>
                        <?php elseif($quoteReq->status == 8): ?>
                        <p class="badge bg-primary">Status: Driver Accepted</p>
                        <?php elseif($quoteReq->status == 9): ?>
                        <p class="badge bg-primary">Status: Driver Loading</p>
                        <?php elseif($quoteReq->status == 10): ?>
                        <p class="badge bg-primary">Status: Driver Carrying</p>
                        <?php elseif($quoteReq->status == 11): ?>
                        <p class="badge bg-success">Status: Load Arrived</p>
                        <?php elseif($quoteReq->status == 12): ?>
                        <p class="badge bg-success">Status: Completed</p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if($quoteReq->status < 8): ?>
                <div class="row mb-5">
                    <div class="col-lg-12">
                        <div class="bg-light p-3 m-3 d-flex flex-column justify-content-between">
                            <h5>Customer Information</h5>
                            <div class="row ps-3 mt-3">
                                <div class="col-lg-4">
                                    <p><small class="text-default text-uppercase">Customer Name</small>: <span class="fw-bold"><?php echo e($user->first_name.' '.$user->last_name); ?></span></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><small class="text-default text-uppercase">Customer Email</small>: <span class="fw-bold"><?php echo e($user->email); ?></span></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><small class="text-default text-uppercase">Customer Phone</small>: <span class="fw-bold"><?php echo e($user->phone); ?></span></p>
                                </div>
                                <div class="col-lg-12">
                                    <p><small class="text-default text-uppercase">Customer Comment</small>: <span class="fw-bold"><?php echo e($quoteReq->comment); ?></span></p>
                                </div>
                            </div>
                            <div class="text-end">
                                <p class="badge bg-secondary mb-0">Requested at: <span class="fw-bold"><?php echo e($quoteReq->created_at); ?></span></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <form method="POST" action="<?php echo e(route('manager.quote.update')); ?>" class="bg-light p-3 m-3">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="quoteId" value="<?php echo e($quoteReq->id); ?>">
                            <h5>Request Information</h5>
                            <div class="row px-3 mb-3">
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="pickupCity">Pickup City / State <span class="text-danger">*</span> :</label></small>
                                    <input type="text" id="pickupCity" name="pickupCity" class="form-control" value="<?php echo e($quoteReq->pickup); ?>" required>
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="deliveryCity">Delivery City / State <span class="text-danger">*</span> :</label></small>
                                    <input type="text" id="deliveryCity" name="deliveryCity" class="form-control" value="<?php echo e($quoteReq->delivery); ?>" required>
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="pickupDate">Pickup Date <span class="text-danger">*</span> :</label></small>
                                    <input type="date" id="pickupDate" name="pickupDate" class="form-control" value="<?php echo e(date('Y-m-d', strtotime($quoteReq->pickupDate))); ?>" required>
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="deliveryDate">Delivery Date <span class="text-danger">*</span> :</label></small>
                                    <input type="date" id="deliveryDate" name="deliveryDate" class="form-control" value="<?php echo e(date('Y-m-d', strtotime($quoteReq->deliveryDate))); ?>" required>
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="commodity">Commodity <span class="text-danger">*</span> :</label></small>
                                    <input type="text" id="commodity" name="commodity" class="form-control" value="<?php echo e($quoteReq->commodity); ?>" required>
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="dimension">Dimension :</label></small>
                                    <input type="text" id="dimension" name="dimension" class="form-control" value="<?php echo e($quoteReq->dimension); ?>">
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="weight">Weight :</label></small>
                                    <input type="text" id="weight" name="weight" class="form-control" value="<?php echo e($quoteReq->weight); ?>">
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="temperature">Temperature Condition :</label></small>
                                    <input type="text" id="temperature" name="temperature" class="form-control" value="<?php echo e($quoteReq->temperature); ?>">
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="equipment">Equipment :</label></small>
                                    <select id="equipment" name="equipment" class="form-control">
                                        <?php $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($equipment->equipmentId); ?>" <?php if($equipment->equipmentId == $quoteReq->equipment): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($equipment->equipmentName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <small><label class="text-default text-uppercase" for="trailerSize">TrailerSize :</label></small>
                                    <select id="trailerSize" name="trailerSize" class="form-control">
                                        <?php $__currentLoopData = $trailerSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trailerSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($trailerSize->trailerSizeId); ?>" <?php if($trailerSize->trailerSizeId == $quoteReq->trailerSize): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($trailerSize->trailerSizeName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="text-center my-4">
                                <button class="btn btn-success w-100p">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backendlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LOCALHOST\quickfreight\quickfreight\resources\views/manager/quote_edit.blade.php ENDPATH**/ ?>