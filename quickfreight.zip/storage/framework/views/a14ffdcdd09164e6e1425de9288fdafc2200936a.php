<h3>Quick Freight Enterprise</h3>
<p>Hello. <?php echo e($driver_name); ?>!</p>
<p>In accordance with the contract with your company, we will provide you with additional information about the transport request assigned to you.</p>
<p>Please log in our site and check the quote.</p>
<a href = "<?php echo e(route('login.driver')); ?>">Quick Freight Enterprise Inc Service</a>
<p>Email: <?php echo e($driver_email); ?></p>
<p>Verify Code: <?php echo e($verify_code); ?></p>
<br>
<small>QUICK FREIGHT ENTERPRISE</small><br>
<small>15867 SW 147th LN</small><br>
<small>MIAMI, FL 33196</small><br>
<small>+1 786 208 9900</small>
<?php /**PATH /home3/yojae/public_html/resources/views/mail/driver_quote.blade.php ENDPATH**/ ?>