<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Registered Carriers</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Carriers</li>
        </ol>
        <div class="card mb-4">
            <div class="card-body table-responsive">
                <table class="table-centered display" id="carriersTable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>US DOT Number</th>
                            <th>Carrier Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $carriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($carrier->dot_number); ?></td>
                            <td><?php echo e($carrier->legal_name); ?></td>
                            <td><?php echo e($carrier->email_address); ?></td>
                            <td><?php echo e($carrier->telephone); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('assets/backend/plugins/datatable@1.13.2/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/backend/plugins/datatable@1.13.2/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/manager/carriers.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backendlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/yojae/public_html/resources/views/manager/carriers.blade.php ENDPATH**/ ?>