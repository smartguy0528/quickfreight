<!-- Scroll Up -->
<div id="back-top">
    <a title="Go to Top" href="javascript:void(0);"> <i class="fa fa-arrow-up" aria-hidden="true"></i></a>
</div><?php /**PATH E:\LOCALHOST\quickfreight\quickfreight\resources\views/frontendlayouts/scrollup.blade.php ENDPATH**/ ?>