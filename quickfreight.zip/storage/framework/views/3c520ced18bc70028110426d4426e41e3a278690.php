<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <?php if(Auth::user() && Auth::user()->role == 0): ?>
                <div class="sb-sidenav-menu-heading">Administrator</div>
                <a class="nav-link" href="<?php echo e(route('admin.users')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Managers
                </a>
                <?php endif; ?>

                <?php if(Auth::user() && Auth::user()->role == 1): ?>
                <div class="sb-sidenav-menu-heading">Manager</div>
                <a class="nav-link <?php if(Route::is('manager.dashboard')): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('manager.dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Dashboard
                </a>
                <a class="nav-link <?php if(str_contains(Route::currentRouteName(), 'manager.quotes')): ?> active <?php endif; ?>" href="<?php echo e(route('manager.quotes.requested')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tasks"></i></div>
                    Task Quotes
                </a>
                <a class="nav-link <?php if(Route::is('manager.all.quotes')): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('manager.all.quotes')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    All Quotes
                </a>
                <a class="nav-link <?php if(Route::is('manager.carriers.all')): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('manager.carriers.all')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-truck"></i></div>
                    Carriers
                </a>
                <a class="nav-link <?php if(Route::is('manager.quote.invoices')): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('manager.quote.invoices')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-file-invoice-dollar"></i></div>
                    Request Order History
                </a>
                <?php endif; ?>

                <?php if(Auth::user() && Auth::user()->role == 2): ?>
                    <div class="sb-sidenav-menu-heading">Customer</div>
                    <a class="nav-link <?php if(Route::is('customer.welcome')): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('customer.welcome')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-calendar-check"></i></div>
                        Home
                    </a>
                    <?php $__currentLoopData = $myQuotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myQuote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="nav-link <?php if(Route::is('customer.quotecheck') && Route::current()->parameters['id'] == $myQuote->id): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('customer.quotecheck', $myQuote->id)); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-calendar-check"></i></div>
                            Check Quote (<?php echo e($myQuote->id_alias); ?>)
                        </a>
                        <?php if($myQuote->status >= 8): ?>
                            <a class="nav-link <?php if(Route::is('customer.quote.status') && Route::current()->parameters['id'] == $myQuote->id): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('customer.quote.status', $myQuote->id)); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-truck-moving"></i></div>
                                Load Status (<?php echo e($myQuote->id_alias); ?>)
                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(Auth::guard('carrierguard')->user()): ?>
                <div class="sb-sidenav-menu-heading">Carrier</div>
                <a class="nav-link" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts2" aria-expanded="true" aria-controls="collapseLayouts2">
                    <div class="sb-nav-link-icon"><i class="fas fa-tasks"></i></div>
                    Task Quotes
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapsed show" id="collapseLayouts2" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php if(Route::is('carrier.quotes')): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('carrier.quotes')); ?>">Requested Quotes</a>
                        <a class="nav-link <?php if(Route::is('carrier.quotes.published')): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('carrier.quotes.published')); ?>">Published Quotes</a>
                        <a class="nav-link <?php if(Route::is('carrier.quotes.completed')): ?> <?php echo e('active'); ?> <?php endif; ?>" href="<?php echo e(route('carrier.quotes.completed')); ?>">Completed Quotes</a>
                    </nav>
                </div>
                <?php endif; ?>

                <?php if(Auth::user() && Auth::user()->role == 4): ?>
                <div class="sb-sidenav-menu-heading">Driver</div>
                <a class="nav-link" href="<?php echo e(route('driver.status')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-truck-moving"></i></div>
                    Load Status
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <span class="small">Logged in as a</span>
            <span>
                <?php if(Auth::user()): ?>
                    <?php switch(Auth::user()->role):
                        case (0): ?>
                            Administrator
                            <?php break; ?>
                        <?php case (1): ?>
                            Manager
                            <?php break; ?>
                        <?php case (2): ?>
                            Customer
                            <?php break; ?>
                        <?php case (3): ?>
                            Carrier
                            <?php break; ?>
                        <?php case (4): ?>
                            Driver
                            <?php break; ?>
                        <?php default: ?>
                            <?php break; ?>
                    <?php endswitch; ?>
                <?php endif; ?>
            </span>
        </div>
    </nav>
</div>
<?php /**PATH E:\LOCALHOST\quickfreight\quickfreight\resources\views/backendlayouts/sidebar.blade.php ENDPATH**/ ?>