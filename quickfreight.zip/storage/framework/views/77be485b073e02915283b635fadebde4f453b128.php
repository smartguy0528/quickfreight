<?php if(session('errors') && session('errors')->first('message')): ?>
<input type="hidden" class="errorMsg" value="<?php echo e(session('errors')->first('message')); ?>">
<?php endif; ?>

<?php if(Session::has('success')): ?>
<div class="d-none" id="successMsg">
    <?php echo e(Session('success')); ?>

</div>
<?php endif; ?>
<?php /**PATH /home3/yojae/public_html/resources/views/backendlayouts/toaster.blade.php ENDPATH**/ ?>