

<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Carrier Invoice Details</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.quote.invoices')); ?>">Completed Quotes</a></li>
            <li class="breadcrumb-item active">Carrier Invoice Details</li>
        </ol>
        <div class="card mb-4">
            <div class="card-body table-responsive p-5">
                <button class="btn btn-info float-end">Export to PDF</button>
                <h5 class="mt-3">Request Information</h5>
                <table class="table mb-0">
                    <tr>
                        <td>Quote ID: <?php echo e($quote->id_alias); ?></td>
                        <td>Customer Name: <?php echo e($quote->customer_name); ?></td>
                        <td>Email Address: <?php echo e($quote->customer_email); ?></td>
                    </tr>
                    <tr>
                        <td>Company Name: <?php echo e($quote->company_name); ?></td>
                        <td>Company Address: <?php echo e($quote->company_address); ?></td>
                        <td>Phone Number: <?php echo e($quote->customer_phone); ?></td>
                    </tr>
                    <tr>
                        <td>Pickup City / State: <?php echo e($quote->pickup); ?></td>
                        <td>Delivery City / State: <?php echo e($quote->delivery); ?></td>
                        <td>Delivery Date: <?php echo e($quote->deliveryDate); ?></td>
                    </tr>
                    <tr>
                        <td>Commodity: <?php echo e($quote->commodity); ?></td>
                        <td>Demension: <?php echo e($quote->dimension); ?></td>
                        <td>Weight: <?php echo e($quote->weight); ?></td>
                    </tr>
                </table>
                <table class="table">
                    <tr>
                        <td>Comment:</td>
                        <td><?php echo e($quote->comment); ?></td>
                    </tr>
                </table>

                <h5 class="mt-5">Driver Information</h5>
                <table class="table mb-0">
                    <tr>
                        <td colspan="2">Carrier Company: <?php echo e($quote->carrier_name); ?></td>
                        <td>Driver Name: <?php echo e($quote->driver_name); ?></td>
                    </tr>
                    <tr>
                        <td>Truck Type: <?php echo e($quote->truck_type); ?></td>
                        <td>Truck Number: <?php echo e($quote->truck_num); ?></td>
                        <td>Truck Capacity: <?php echo e($quote->truck_capacity); ?></td>
                    </tr>
                </table>

                <h5 class="mt-5">Quote to Carrier</h5>
                <p class="ps-5">Delivery Cost: ($) <?php echo e($quote->deliver_cost); ?></p>
                <p class="ps-5">Comment from company: <?php echo e($quote->company_carrier_comment); ?></p>
                
                <h5 class="mt-5">Completed Status</h5>
                <p class="ps-5">Completed Time: <?php echo e($quote->updated_at); ?></p>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backendlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/yojae/public_html/resources/views/manager/invoice_carrier.blade.php ENDPATH**/ ?>