<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; Quick Fright INC 2023</div>
            <div>
                <a href="javascript:void(0);">Privacy Policy</a>
                &middot;
                <a href="javascript:void(0);">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer><?php /**PATH E:\LOCALHOST\quickfreight\quickfreight\resources\views/backendlayouts/footer.blade.php ENDPATH**/ ?>