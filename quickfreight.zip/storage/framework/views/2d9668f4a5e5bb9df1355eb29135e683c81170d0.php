<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Thanks for using our service</title>
</head>
<body>
	<h3>Thanks for using our service</h3>
	<p>Your request successfully sent.</p>
	<p>Please wait a bit time till our service accept your order.</p>
	<br>
	<small>QUICK FREIGHT ENTERPRISE</small><br>
	<small>15867 SW 147th LN</small><br>
	<small>MIAMI, FL 33196</small><br>
	<small>+1 786 208 9900</small>
</body>
</html>
<?php /**PATH /home3/yojae/public_html/resources/views/mail/customer_confirm.blade.php ENDPATH**/ ?>