<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontendlayouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <!-- Hero Start -->
        <div class="slider-area2">
            <div class="slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap hero-cap2 text-center pt-70">
                                <h2 id="services">Our Services</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero End -->
        <!-- Order Form Start -->
        <section class="order-form-main">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-wrapper">
                            <!--Section Title  -->
                            <div class="form-tittle">
                                <div class="row ">
                                    <div class="col-lg-11 col-md-10 col-sm-10">
                                        <div class="section-tittle">
                                            <span>Place Order</span>
                                            <h2>Place Order Now</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Order Form  -->
                            <form method="GET" id="orderForm" action="<?php echo e(route('quote.request')); ?>" class="form-order contact_form pl-65 pr-65 pt-30 pb-30">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="firstName">First Name <span class="text-danger">*</span></label>
                                            <input id="firstName" name="firstName" class="form-control" value="<?php echo e(old('firstName')); ?>">
                                            <?php if($errors->has('firstName')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('firstName')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('firstName')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="lastName">Last Name <span class="text-danger">*</span></label>
                                            <input id="lastName" name="lastName" class="form-control" value="<?php echo e(old('lastName')); ?>">
                                            <?php if($errors->has('lastName')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('lastName')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('lastName')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="email">Email <span class="text-danger">*</span></label>
                                            <input name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>">
                                            <?php if($errors->has('email')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('email')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="phone">Phone <span class="text-danger">*</span></label>
                                            <input id="phone" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>">
                                            <?php if($errors->has('phone')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('phone')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('phone')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="pickup">Pickup City / State <span class="text-danger">*</span></label>
                                            <input id="pickup" name="pickup" class="form-control" value="<?php echo e(old('pickup')); ?>">
                                            <?php if($errors->has('pickup')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('pickup')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('pickup')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="delivery">Delivery City / State <span class="text-danger">*</span></label>
                                            <input id="delivery" class="form-control" type="text" name="delivery" value="<?php echo e(old('delivery')); ?>">
                                            <?php if($errors->has('delivery')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('delivery')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('delivery')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="pickupDate">Pickup Date <span class="text-danger">*</span></label>
                                            <input type="text" id="pickupDate" class="form-control" name="pickupDate" onblur="(this.type='text')" onfocus="(this.type='date')" value="<?php echo e(old('pickupDate')); ?>">
                                            <?php if($errors->has('pickupDate')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('pickupDate')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('pickupDate')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="deliveryDate">Delivery Date <span class="text-danger">*</span></label>
                                            <input type="text" id="deliveryDate" class="form-control" name="deliveryDate" onblur="(this.type='text')" onfocus="(this.type='date')" value="<?php echo e(old('deliveryDate')); ?>">
                                            <?php if($errors->has('deliveryDate')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('deliveryDate')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('deliveryDate')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="commodity">Commodity <span class="text-danger">*</span></label>
                                            <input id="commodity" class="form-control" type="text" name="commodity" value="<?php echo e(old('commodity')); ?>">
                                            <?php if($errors->has('commodity')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('commodity')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('commodity')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="dimension">Dimension</label>
                                            <input id="dimension" class="form-control" type="text" name="dimension" value="<?php echo e(old('dimension')); ?>">
                                            <?php if($errors->has('dimension')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('dimension')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('dimension')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="weight">Weight</label>
                                            <input id="weight" class="form-control" type="text" name="weight" value="<?php echo e(old('weight')); ?>">
                                            <?php if($errors->has('weight')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('weight')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('weight')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="temperature">Temperature Condition</label>
                                            <input id="temperature" class="form-control" type="text" name="temperature" value="<?php echo e(old('temperature')); ?>">
                                            <?php if($errors->has('temperature')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('temperature')); ?></small>
                                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('temperature')); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 mb-30">
                                        <div class="form-group">
                                            <label for="equipment">Equipment</label>
                                            <select class="form-control w-100" name="equipment" id="equipment">
                                                <?php $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($equipment->equipmentId); ?>"><?php echo e($equipment->equipmentName); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 mb-30">
                                        <div class="form-group">
                                            <label for="trailerSize">Trailer Size</label>
                                            <select class="form-control w-100" name="trailerSize" id="trailerSize">
                                                <?php $__currentLoopData = $trailer_size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trailer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($trailer->trailerSizeId); ?>"><?php echo e($trailer->trailerSizeName); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="comment">Freight Description / Shipping Details / Comments</label>
                                            <textarea class="form-control w-100" name="comment" id="comment" cols="30" rows="5"><?php echo e(old('comment')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-center mb-30">
                                            <div class="primary-checkbox">
                                                <input type="checkbox" id="policy-checkbox">
                                                <label class="border border-danger border-2" for="policy-checkbox"></label>
                                            </div>
                                            <label for="policy-checkbox" class="fw-normal ml-3 mb-0">
                                                &nbsp; I agree to Quick Fright Enterprise INC's <a class="text-info" target="_blank" href="<?php echo e(route('frontend.privacy')); ?>#terms">Terms of Use</a>
                                                and <a class="text-info" target="_blank" href="<?php echo e(route('frontend.privacy')); ?>#privacy">Privacy Cookie Policy</a>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <!-- Google reCaptcha v2 -->
                                        <?php echo htmlFormSnippet(); ?>

                                        <?php if($errors->has('g-recaptcha-response')): ?>
                                        <div>
                                            <small class="text-danger"><?php echo e($errors->first('g-recaptcha-response')); ?></small>
                                            <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('g-recaptcha-response')); ?>">
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div id="request" class="form-group mt-5">
                                    <button id="submitBtn" class="btn btn-danger">Send</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Order Form End -->
        <!-- Request Service Start -->
        <section id="reqQuote" class="wantToWork-area w-padding section-bg" data-background="<?php echo e(asset('assets/frontend/img/gallery/section_bg02.jpg')); ?>">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col-lg-7 col-md-8 col-sm-10">
                        <div class="wantToWork-caption">
                            <h2>Do you want to know about your loading status?</h2>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3">
                        <a href="<?php echo e(route('login.customer')); ?>" class="btn btn-danger" style="width: 220px">Request Service</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Request Service End -->
    </main>

    <?php echo $__env->make('frontendlayouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('frontendlayouts.scrollup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/frontend/js/pages/services.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontendlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LOCALHOST\quickfreight\quickfreight\resources\views/frontend/services.blade.php ENDPATH**/ ?>