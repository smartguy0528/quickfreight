<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">
            <?php if($status == 1): ?>
                Requested Quotes
            <?php elseif($status == 2): ?>
                Checked Quotes
            <?php elseif($status == 3): ?>
                Approved Quotes
            <?php elseif($status == 4): ?>
                Rejected Quotes
            <?php elseif($status == 5): ?>
                Confirmed Quotes
            <?php elseif($status == 6): ?>
                Submitted Quotes
            <?php elseif($status == 7): ?>
                Published Quotes
            <?php elseif($status > 7 && $status < 12): ?>
                On going Quotes
            <?php elseif($status == 12): ?>
                Completed Quotes
            <?php endif; ?>
        </h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.all.quotes')); ?>">Quotes</a></li>
            <?php if($status == 1): ?>
            <li class="breadcrumb-item active">Requested Quotes</a></li>
            <?php elseif($status == 2): ?>
            <li class="breadcrumb-item active">Checked Quotes</a></li>
            <?php elseif($status == 3): ?>
            <li class="breadcrumb-item active">Approved Quotes</a></li>
            <?php elseif($status == 4): ?>
            <li class="breadcrumb-item active">Rejected Quotes</a></li>
            <?php elseif($status == 5): ?>
            <li class="breadcrumb-item active">Confirmed Quotes</a></li>
            <?php elseif($status == 6): ?>
            <li class="breadcrumb-item active">Submitted Quotes</a></li>
            <?php elseif($status == 7): ?>
            <li class="breadcrumb-item active">Published Quotes</a></li>
            <?php elseif($status > 7 && $status < 12): ?>
            <li class="breadcrumb-item active">On going Quotes</a></li>
            <?php elseif($status == 12): ?>
            <li class="breadcrumb-item active">Completed Quotes</a></li>
            <?php endif; ?>
        </ol>
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between pt-3 pb-0">
                <a href="<?php echo e(route('manager.quotes.requested')); ?>" class="btn text-uppercase
                    <?php if($status == 1): ?>
                    btn-info
                    <?php elseif($status_count['quote_requested']): ?>
                    btn-light fw-bold
                    <?php else: ?>
                    disabled text-muted
                    <?php endif; ?>">Requested (<?php echo e($status_count['quote_requested']); ?>)</a>
                <a href="<?php echo e(route('manager.quotes.checked')); ?>" class="btn text-uppercase
                    <?php if($status == 2): ?>
                    btn-info
                    <?php elseif($status_count['quote_checked']): ?>
                    btn-light fw-bold
                    <?php else: ?>
                    disabled text-muted
                    <?php endif; ?>">Checked (<?php echo e($status_count['quote_checked']); ?>)</a>
                <a href="<?php echo e(route('manager.quotes.approved')); ?>" class="btn text-uppercase
                    <?php if($status == 3): ?>
                    btn-info
                    <?php elseif($status_count['quote_approved']): ?>
                    btn-light fw-bold
                    <?php else: ?>
                    disabled text-muted
                    <?php endif; ?>">Approved (<?php echo e($status_count['quote_approved']); ?>)</a>
                <a href="<?php echo e(route('manager.quotes.rejected')); ?>" class="btn text-uppercase
                    <?php if($status == 4): ?>
                    btn-info
                    <?php elseif($status_count['quote_rejected']): ?>
                    btn-light fw-bold
                    <?php else: ?>
                    disabled text-muted
                    <?php endif; ?>">Rejected (<?php echo e($status_count['quote_rejected']); ?>)</a>
                <a href="<?php echo e(route('manager.quotes.confirmed')); ?>" class="btn text-uppercase
                    <?php if($status == 5): ?>
                    btn-info
                    <?php elseif($status_count['quote_confirmed']): ?>
                    btn-light fw-bold
                    <?php else: ?>
                    disabled text-muted
                    <?php endif; ?>">Confirmed (<?php echo e($status_count['quote_confirmed']); ?>)</a>
                <a href="<?php echo e(route('manager.quotes.submitted')); ?>" class="btn text-uppercase
                    <?php if($status == 6): ?>
                    btn-info
                    <?php elseif($status_count['quote_submitted']): ?>
                    btn-light fw-bold
                    <?php else: ?>
                    disabled text-muted
                    <?php endif; ?>">Submitted (<?php echo e($status_count['quote_submitted']); ?>)</a>
                <a href="<?php echo e(route('manager.quotes.published')); ?>" class="btn text-uppercase
                    <?php if($status == 7): ?>
                    btn-info
                    <?php elseif($status_count['quote_published']): ?>
                    btn-light fw-bold
                    <?php else: ?>
                    disabled text-muted
                    <?php endif; ?>">Published (<?php echo e($status_count['quote_published']); ?>)</a>
                <a href="<?php echo e(route('manager.quotes.ongoing')); ?>" class="btn text-uppercase
                    <?php if($status > 7 && $status < 12): ?>
                    btn-info
                    <?php elseif($status_count['quote_ongoing']): ?>
                    btn-light fw-bold
                    <?php else: ?>
                    disabled text-muted
                    <?php endif; ?>">On Going (<?php echo e($status_count['quote_ongoing']); ?>)</a>
                <a href="<?php echo e(route('manager.quotes.completed')); ?>" class="btn text-uppercase
                    <?php if($status == 12): ?>
                    btn-info
                    <?php elseif($status_count['quote_completed']): ?>
                    btn-light fw-bold
                    <?php else: ?>
                    disabled text-muted
                    <?php endif; ?>">Completed (<?php echo e($status_count['quote_completed']); ?>)</a>
            </div>
            <div class="card-body table-responsive">
                <table id="quoteTable" class="table-centered display">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Quote ID</th>
                            <th>Requested Time</th>
                            <th>Customer Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td><?php echo e($quote->id_alias); ?></td>
                            <td><?php echo e($quote->updated_at); ?></td>
                            <td><?php echo e($quote->first_name . ' ' . $quote->last_name); ?></td>
                            <td><?php echo e($quote->email); ?></td>
                            <td><?php echo e($quote->phone); ?></td>
                            <td><a href="<?php echo e(route('manager.quote.details', $quote->id)); ?>" class="btn btn-info w-125p btn-sm"><i class="far fa-calendar-check"></i> Check Details</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('assets/backend/plugins/datatable@1.13.2/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/backend/plugins/datatable@1.13.2/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/manager/quotes.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backendlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LOCALHOST\quickfreight\quickfreight\resources\views/manager/quotes.blade.php ENDPATH**/ ?>