<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontendlayouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <!-- Hero Start -->
        <div class="slider-area2">
            <div class="slider-height2 d-flex align-items-md-center align-items-end">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap hero-cap2 pt-80 pb-20 text-center">
                                <?php if($quoteReq->status < 13): ?>
                                <h2>Welcome to our service, <?php echo e($customer->first_name); ?></h2>
                                <h3 class="text-white">Quote ID: #<?php echo e($quoteReq->id_alias); ?></h3>
                                <?php else: ?>
                                <h2 class="text-warning">Congratulations!</h2>
                                <h3 class="text-white"> Your transport request is successfully completed.</h3>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero End -->


        <!-- Customer Area start  -->
        <section>
            <div class="container bg-white p-3 p-sm-5">
                <?php if($quoteReq->status < 9): ?>
                    <!-- Common Information Start -->
                    <div class="row mb-5">
                        <div class="col-12">
                            <div class="section-tittle">
                                <span>My Order Content</span>
                                <h3 class="mb-4">Order ID: #<?php echo e($quoteReq->id_alias); ?></h3>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="row">
                                        <div class="col-sm-6 text-center text-sm-start">
                                            <img src="<?php echo e(asset('assets/frontend/img/customer/customer_image.jpg')); ?>"
                                                class="img-thumbnail" alt="...">
                                        </div>
                                        <div class="col-sm-6 d-flex flex-column justify-content-between">
                                            <div class="text-center text-sm-start">
                                                <?php if($quoteReq->status == 1): ?>
                                                    <p class="badge bg-success my-3">Status: Order Requested</p>
                                                <?php elseif($quoteReq->status == 2): ?>
                                                    <p class="badge bg-success my-3">Status: Order Accepted</p>
                                                <?php elseif($quoteReq->status == 3): ?>
                                                    <p class="badge bg-success my-3">Status: Order Approved</p>
                                                <?php elseif($quoteReq->status == 4): ?>
                                                    <p class="badge bg-danger my-3">Status: Order Rejected</p>
                                                <?php elseif($quoteReq->status == 5): ?>
                                                    <p class="badge bg-success my-3">Status: Order Approved</p>
                                                <?php elseif($quoteReq->status == 6): ?>
                                                    <p class="badge bg-success my-3">Status: Order Approved</p>
                                                <?php elseif($quoteReq->status == 7): ?>
                                                    <p class="badge bg-success my-3">Status: Order Approved</p>
                                                <?php elseif($quoteReq->status == 8): ?>
                                                    <p class="badge bg-primary my-3">Status: Order Approved</p>
                                                <?php endif; ?>
                                            </div>
                                            <div>
                                                <p class="mb-2"><small class="text-default text-uppercase">Name</small>:
                                                    <span
                                                        class="fw-bold"><?php echo e($customer->first_name . ' ' . $customer->last_name); ?></span>
                                                </p>
                                                <p class="mb-2"><small class="text-default text-uppercase">Email</small>:
                                                    <span class="fw-bold"><?php echo e($customer->email); ?></span></p>
                                                <p class="mb-2"><small class="text-default text-uppercase">Phone</small>:
                                                    <span class="fw-bold"><?php echo e($customer->phone); ?></span></p>
                                            </div>
                                        </div>
                                        <div class="col-12 mt-3">
                                            <p class="mb-2"><small class="text-default text-uppercase">Company/Home
                                                    Info</small>: <span class="fw-bold">
                                                    <?php if($quoteApp): ?>
                                                        <?php echo e($quoteApp->company_name); ?>

                                                    <?php endif; ?>
                                                </span>
                                            </p>
                                            <p class="mb-2"><small class="text-default text-uppercase">Company/Home
                                                    Address</small>: <span class="fw-bold">
                                                    <?php if($quoteApp): ?>
                                                        <?php echo e($quoteApp->company_address); ?>

                                                    <?php endif; ?>
                                                </span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <p class="mb-2"><small class="text-default text-uppercase">City / State</small>: <span
                                            class="fw-bold"><?php echo e($quoteReq->pickup); ?></span></p>
                                    <p class="mb-2"><small class="text-default text-uppercase">Delivery City /
                                            State</small>: <span class="fw-bold"><?php echo e($quoteReq->delivery); ?></span></p>
                                    <p class="mb-2"><small class="text-default text-uppercase">Date</small>: <span
                                            class="fw-bold"><?php echo e(date('Y-m-d', strtotime($quoteReq->pickupDate))); ?></span>
                                    </p>
                                    <p class="mb-2"><small class="text-default text-uppercase">Delivery Date</small>:
                                        <span
                                            class="fw-bold"><?php echo e(date('Y-m-d', strtotime($quoteReq->deliveryDate))); ?></span>
                                    </p>
                                    <p class="mb-2"><small class="text-default text-uppercase">Commodity</small>: <span
                                            class="fw-bold"><?php echo e($quoteReq->commodity); ?></span></p>
                                    <p class="mb-2"><small class="text-default text-uppercase">Dimension</small>: <span
                                            class="fw-bold"><?php echo e($quoteReq->dimension); ?></span></p>
                                    <p class="mb-2"><small class="text-default text-uppercase">Weight</small>: <span
                                            class="fw-bold"><?php echo e($quoteReq->weight); ?></span></p>
                                    <p class="mb-2"><small class="text-default text-uppercase">Temperature
                                            Condition</small>: <span class="fw-bold"><?php echo e($quoteReq->temperature); ?></span>
                                    </p>
                                    <p class="mb-2"><small class="text-default text-uppercase">Equipment</small>: <span
                                            class="fw-bold"><?php echo e($quoteReq->equipment_name); ?></span></p>
                                    <p class="mb-2"><small class="text-default text-uppercase">Comment</small>: <span
                                            class="fw-bold"><?php echo e($quoteReq->comment); ?></span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Common Information End -->
                <?php endif; ?>

                <!-- Status 2 ~: Order Checked -->
                <?php if($quoteReq->status > 1 && $quoteReq->status < 9): ?>
                    <div class="row mb-5">
                        <div class="col-12">
                            <div class="section-tittle">
                                <span>Comapny Suggestion</span>
                                <h3 class="mb-4">Quick Freight Enterprise INC.</h3>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="row ps-3 ps-sm-5">
                                <div class="col-md-6">
                                    <p><small>Delivery Cost</small>: $ <?php echo e($quoteApp->cost); ?></p>
                                    <p class="pb-3 border-bottom"><small>Additional Fee</small>: $ <?php echo e($quoteApp->fee); ?></p>
                                    <p><small>Total Cost</small>: <span class="fw-bold">$
                                            <?php echo e($quoteApp->total_cost); ?></span></p>
                                </div>
                                <div class="col-md-6">
                                    <p><small>Company Comment</small></p>
                                    <p class="ps-4 fw-bold"><small><?php echo e($quoteApp->company_comment); ?></small></p>
                                </div>
                            </div>
                        </div>
                        <?php if($quoteReq->status == 2): ?>
                            <div class="col-12 d-flex justify-content-center">
                                <div class="mt-3">
                                    <button class="btn btn-primary bg-primary me-3" data-bs-toggle="modal"
                                        data-bs-target="#approveModal">Approve</button>
                                    <button class="btn btn-danger me-3" data-bs-toggle="modal"
                                        data-bs-target="#rejectModal">Reject</button>
                                    <?php if($quoteApp->old_reject_reason): ?>
                                        <button class="btn btn-secondary" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal">Delete</button>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <!-- Status 2 ~: Order Checked End -->

                <!-- Status 4: Order Rejected -->
                <?php if($quoteReq->status == 4 && $quoteReq->status < 9): ?>
                    <div class="row mb-5">
                        <div class="col-12">
                            <div class="section-tittle">
                                <span>Reject Reason</span>
                                <h3 class="mb-4"><?php echo e($customer->first_name . ' ' . $customer->last_name); ?></h3>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="row ps-3 ps-sm-5">
                                <p class="text-danger"><?php echo e($quoteApp->reject_reason); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- Status 4: Order Rejected End -->



                <!-- Status 8 ~ : Load Status -->
                <?php if($quoteReq->status >= 9): ?>
                    <div class="row mb-5">
                        <div class="col-12">
                            <div class="section-tittle">
                                <span>My Order Status</span>
                                <div>
                                    <h3 class="">Order ID: #<?php echo e($quoteReq->id_alias); ?></h3>
                                    <?php if($quoteReq->status < 11): ?>
                                        <small class="ms-4 badge bg-primary">Status: On Transport</small>
                                    <?php elseif($quoteReq->status == 11): ?>
                                        <small class="ms-4 badge bg-success">Status: Arrived</small>
                                    <?php elseif($quoteReq->status > 11): ?>
                                        <small class="ms-4 badge bg-success">Status: Completed</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="h-100 bg-white p-3 d-flex align-items-center">
                                <div>
                                    <?php if($quoteReq->status < 11): ?>
                                        <?php
                                            $now = new DateTime();
                                            $pastTime = new DateTime($driver->updated_at); // replace with your past time

                                            $interval = $now->diff($pastTime);
                                            $timeDiff = $interval->format('%d days %h hours %i minutes');
                                        ?>
                                        <p class="ms-1 ms-sm-5 mt-2"><small class="text-uppercase">Current Location</small>: <span
                                                class="fw-bold"><?php echo e($location->location); ?></span></p>
                                        <p class="ms-1 ms-sm-5 mt-2"><small class="text-uppercase">Latitude</small>: <span
                                                class="fw-bold"><?php echo e($location->latitude); ?></span></p>
                                        <p class="ms-1 ms-sm-5 mt-2"><small class="text-uppercase">Longitude</small>: <span
                                                class="fw-bold"><?php echo e($location->longitude); ?></span></p>
                                        <p class="ms-1 ms-sm-5 mt-2"><small class="text-uppercase">Transport Time</small>: <span
                                                class="fw-bold"><?php echo e($timeDiff); ?></span></p>
                                    <?php else: ?>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">City /
                                                State</small>: <span class="fw-bold"><?php echo e($quoteReq->pickup); ?></span></p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Delivery City /
                                                State</small>: <span class="fw-bold"><?php echo e($quoteReq->delivery); ?></span></p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Date</small>:
                                            <span
                                                class="fw-bold"><?php echo e(date('Y-m-d', strtotime($quoteReq->pickupDate))); ?></span>
                                        </p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Delivery
                                                Date</small>: <span
                                                class="fw-bold"><?php echo e(date('Y-m-d', strtotime($quoteReq->deliveryDate))); ?></span>
                                        </p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Commodity</small>:
                                            <span class="fw-bold"><?php echo e($quoteReq->commodity); ?></span></p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Dimension</small>:
                                            <span class="fw-bold"><?php echo e($quoteReq->dimension); ?></span></p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Weight</small>:
                                            <span class="fw-bold"><?php echo e($quoteReq->weight); ?></span></p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Temperature
                                                Condition</small>: <span
                                                class="fw-bold"><?php echo e($quoteReq->temperature); ?></span></p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Equipment</small>:
                                            <span class="fw-bold"><?php echo e($quoteReq->equipment_name); ?></span></p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Comment</small>:
                                            <span class="fw-bold"><?php echo e($quoteReq->comment); ?></span></p>
                                        <p class="mb-2 ms-4"><small class="text-default text-uppercase">Cost</small>:
                                            <span class="fw-bold">$ <?php echo e($quoteApp->total_cost); ?></span></p>
                                        
                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="h-100 bg-white text-center">
                                <?php if($quoteReq->status >= 12): ?>
                                    <p><span class="fw-bold">BOL Picture:</span> <a class="text-primary"
                                            href="<?php echo e(url('storage' . $quoteComp->bol_path)); ?>" target="_blank">Check
                                            Here</a></p>
                                    <img src="<?php echo e(url('storage' . $quoteComp->bol_path)); ?>" class="img-thumbnail"
                                        style="max-height: 400px" alt="BOL Picture">
                                <?php else: ?>
                                    
                                    <div id="map" class="position-relative rounded w-100" style="min-height: 400px; height: 100%;"></div>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- Status 8 ~ : Load Status End -->


                <!-- Status 12 ~ : Payment -->
                <?php if($quoteReq->status >= 12): ?>
                    <div class="row d-flex justify-content-center mb-5">
                        <div class="col-12">
                            <div class="section-tittle">
                                <span>Payment</span>
                                <h4 class="ms-5">$ <?php echo e($quoteApp->total_cost); ?></h4>
                            </div>
                        </div>
                        <?php if($quoteReq->status == 12): ?>
                            <div class="col-md-8 text-center">
                                <div class="row">
                                    <form method="GET" action="<?php echo e(route('customer.stripe')); ?>"
                                        class="col-lg-4 mb-2 text-center">
                                        <input type="hidden" name="quote_id" value="<?php echo e($quoteReq->id); ?>">
                                        <button type="submit" class="btn btn-info bg-info w-100"><i
                                                class="fas fa-credit-card"></i> ACH STRIPE</button>
                                    </form>
                                    <form method="POST"
                                        action="<?php echo e(route('checkout.payment.paypal', ['order' => encrypt($quoteComp->quote_id)])); ?>"
                                        class="col-lg-4 mb-2 text-center">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-primary bg-primary w-100"><i
                                                class="fab fa-paypal"></i> PAYPAL</button>
                                    </form>
                                    <div class="col-lg-4 mb-2 text-center">
                                        <button class="btn btn-success bg-success w-100"><i
                                                class="fab fa-cc-mastercard"></i> Mastercard</button>
                                    </div>
                                </div>
                            </div>
                            <?php if(session()->has('message')): ?>
                                <p class="text-danger text-center"><i class="far fa-times-circle"></i>
                                    <?php echo e(session('message')); ?></p>
                            <?php endif; ?>
                        <?php elseif($quoteReq->status == 13): ?>
                            <div class="col-12">
                                <!-- Payment Message -->
                                <?php if(session()->has('message')): ?>
                                    <p class="text-success text-center"><i class="far fa-check-circle"></i> <?php echo e(session('message')); ?></p>
                                <?php else: ?>
                                    <p class="text-success text-center"><i class="far fa-check-circle"></i> You recent payment is
                                        sucessful with reference code <?php echo e($quoteReq->transaction_id); ?></p>
                                <?php endif; ?>
                                <!-- Payment Message End -->

                                <!-- Invoice -->
                                <div class="text-center">
                                    <a target="_blank" href="<?php echo e(route('customer.invoice.publish')); ?>" type="button" class="btn btn-danger">Publish Invoice</a>
                                    
                                </div>
                                <!-- Invoice Field -->
                            </div>
                            <div class="col-12 mt-5">
                                <div class="section-tittle">
                                    <span>Review</span>
                                    <?php if(!$quoteComp->customer_review): ?>
                                        <h4>Leave your Review</h4>
                                    <?php else: ?>
                                        <h4>Your Review</h4>
                                    <?php endif; ?>
                                </div>
                                <!-- Review Field -->
                                <?php if(!$quoteComp->customer_review): ?>
                                    <form method="POST" action="<?php echo e(route('customer.quote.review')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <textarea name="review" style="height: 140px" class="form-control" required></textarea>
                                        <?php if($errors->has('review')): ?>
                                            <small class="text-danger"><?php echo e($errors->first('review')); ?></small>
                                            <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('review')); ?>">
                                        <?php endif; ?>
                                        <div>
                                            <button type="submit" class="btn btn-success bg-success mt-3">Send</button>
                                        </div>
                                    </form>
                                <?php else: ?>
                                    <div class="bg-light p-3">
                                        <p><?php echo e($quoteComp->customer_review); ?></p>
                                        <p class="text-end mb-0"><small class="text-secondary">(<?php echo e($quoteComp->updated_at); ?>)</small></p>
                                    </div>
                                <?php endif; ?>
                                <!-- Review field End -->
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <!-- Status 12 ~: Payment End -->


                <!-- Current Status Start -->
                <?php if($quoteReq->status < 12): ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="section-tittle">
                                <span>Current Request Status</span>
                                <div class="progress">
                                    <?php if($quoteReq->status == 1): ?>
                                        <div class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                            style="width:20%">Requested</div>
                                    <?php elseif($quoteReq->status == 2): ?>
                                        <div class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                            style="width:30%">Accepted</div>
                                    <?php elseif($quoteReq->status == 3): ?>
                                        <div class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                            style="width:40%">Approved</div>
                                    <?php elseif($quoteReq->status == 4): ?>
                                        <div class="progress-bar bg-danger progress-bar-striped progress-bar-animated"
                                            style="width:20%">Rejected</div>
                                    <?php elseif($quoteReq->status == 5): ?>
                                        <div class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                            style="width:50%">Approved</div>
                                    <?php elseif($quoteReq->status == 6): ?>
                                        <div class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                            style="width:60%">Approved</div>
                                    <?php elseif($quoteReq->status == 7): ?>
                                        <div class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                            style="width:70%">Approved</div>
                                    <?php elseif($quoteReq->status == 8): ?>
                                        <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated"
                                            style="width:80%">To Pickup</div>
                                    <?php elseif($quoteReq->status == 9): ?>
                                        <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated"
                                            style="width:80%">On Loading</div>
                                    <?php elseif($quoteReq->status == 10): ?>
                                        <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated"
                                            style="width:90%">On Transport</div>
                                    <?php elseif($quoteReq->status == 11): ?>
                                        <div class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                            style="width:95%">Arrived</div>
                                    <?php elseif($quoteReq->status == 12): ?>
                                        <div class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                            style="width:100%">Completed</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- Current Status End -->
            </div>
        </section>
        <!-- Customer Area End -->
    </main>

    <?php echo $__env->make('frontendlayouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('frontendlayouts.scrollup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
    <?php if($quoteReq->status == 2): ?>
        <!-- Approve Modal -->
        <div class="modal fade" id="approveModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
            <div class="modal-dialog  modal-dialog-centered modal-dialog-scrollable">
                <form method="POST" action="<?php echo e(route('customer.quote.approve')); ?>" class="modal-content">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h4 class="modal-title">Are you agree with this quote?</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>If so, please complete your information</p>
                        <div class="form-group mb-3">
                            <input class="form-control mt-3" name="company_name" placeholder="Company Name"
                                value="<?php if(old('company_name')): ?><?php echo e(old('company_name')); ?><?php else: ?><?php echo e($quoteApp->company_name); ?><?php endif; ?>">
                            <?php if($errors->has('company_name')): ?>
                                <small class="text-danger"><?php echo e($errors->first('company_name')); ?></small>
                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('company_name')); ?>">
                            <?php endif; ?>
                            <input class="form-control mt-3" name="company_address" placeholder="Company Address"
                                value="<?php if(old('company_address')): ?><?php echo e(old('company_address')); ?><?php else: ?><?php echo e($quoteApp->company_address); ?><?php endif; ?>">
                            <?php if($errors->has('company_address')): ?>
                                <small class="text-danger"><?php echo e($errors->first('company_address')); ?></small>
                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('company_address')); ?>">
                            <?php endif; ?>
                            <input type="hidden" name="quote_id" value="<?php echo e($quoteReq->id); ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary bg-secondary me-3"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="approveBtn" class="btn btn-primary bg-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Reject Modal -->
        <div class="modal fade" id="rejectModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
            <div class="modal-dialog  modal-dialog-centered modal-dialog-scrollable">
                <form method="POST" action="<?php echo e(route('customer.quote.reject')); ?>" class="modal-content">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h4 class="modal-title">Do you reject this quote?</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <p>Can you tell me the reason you reject this quote?</p>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="reject_reason_option" value="Too expensive." id="radio1" checked>
                                <label class="form-check-label" for="radio1">
                                    Too expensive.
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="reject_reason_option" value="I'm not interested in." id="radio2">
                                <label class="form-check-label" for="radio2">
                                    I'm not interested in.
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="reject_reason_option" value="Others." id="radio3">
                                <label class="form-check-label" for="radio3">
                                    Others.
                                </label>
                            </div>
                            <textarea class="form-control mt-3" style="height: 100px;" name="reject_reason"
                                placeholder="Please enter your opinion"><?php if(old('reject_reason')): ?><?php echo e(old('reject_reason')); ?><?php else: ?><?php echo e($quoteApp->reject_reason); ?><?php endif; ?></textarea>
                            <?php if($errors->has('reject_reason')): ?>
                                <small class="text-danger"><?php echo e($errors->first('reject_reason')); ?></small>
                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('reject_reason')); ?>">
                            <?php endif; ?>

                            <input class="form-control mt-3" name="company_name" placeholder="Company / Home"
                                value="<?php if(old('company_name')): ?><?php echo e(old('company_name')); ?><?php else: ?><?php echo e($quoteApp->company_name); ?><?php endif; ?>" required>
                            <?php if($errors->has('company_name')): ?>
                                <small class="text-danger"><?php echo e($errors->first('company_name')); ?></small>
                            <?php endif; ?>
                            <input class="form-control mt-2" name="company_address" placeholder="Company / Home Address"
                                value="<?php if(old('company_address')): ?><?php echo e(old('company_address')); ?><?php else: ?><?php echo e($quoteApp->company_address); ?><?php endif; ?>" required>
                            <?php if($errors->has('company_address')): ?>
                                <small class="text-danger"><?php echo e($errors->first('company_address')); ?></small>
                            <?php endif; ?>


                            <input type="hidden" name="quote_id" value="<?php echo e($quoteReq->id); ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-base me-3"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger btn-base">Submit</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Delete Modal -->
        <div class="modal fade" id="deleteModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
            <div class="modal-dialog  modal-dialog-centered modal-dialog-scrollable">
                <form id="deleteForm" method="post" action="<?php echo e(route('customer.quote.delete')); ?>"
                    class="modal-content">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h4 class="modal-title">Are you sure delete this request?</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>Why do you gonna delete this order?</p>
                        <div class="form-group">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="reject_reason_option" value="Too expensive." id="radio1_d" checked>
                                <label class="form-check-label" for="radio1_d">
                                    Too expensive.
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="reject_reason_option" value="I'm not interested in." id="radio2_d">
                                <label class="form-check-label" for="radio2_d">
                                    I'm not interested in.
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="reject_reason_option" value="Bad service." id="radio3_d">
                                <label class="form-check-label" for="radio3_d">
                                    Bad service.
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="reject_reason_option" value="Others." id="radio4_d">
                                <label class="form-check-label" for="radio4_d">
                                    Others.
                                </label>
                            </div>
                            <textarea class="form-control" style="height: 150px" name="delete_reason" placeholder="Please enter your opinion" required></textarea>
                            <?php if($errors->has('delete_reason')): ?>
                                <small class="text-danger">We are very thankful if you tell us why are you gonna delete
                                    this request.</small>
                                <input type="hidden" class="errorMsg" value="<?php echo e($errors->first('delete_reason')); ?>">
                            <?php endif; ?>
                            <input type="hidden" name="quote_id" value="<?php echo e($quoteReq->id); ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-base me-3"
                            data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" id="deleteBtn" class="btn btn-danger btn-base">Delete</button>
                    </div>
                </form>
            </div>
        </div>

        <?php if(Session::has('show_modal')): ?>
            <input id="show-modal" value="<?php echo e(session('show_modal')); ?>">
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDiZWS8nBscbzohPYAuyaPQx-ADDgt9ujI"></script>
    <script>
        function initMap() {
            console.log("init map");
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 12,
                center: {lat: 0, lng: -180}
            });

            // Get the polyline data from the server
            fetch("<?php echo e(route('api.getpoints', Auth::guard('customerguard')->user()->quote_id)); ?>")
                .then(response => response.json())
                .then(polyline => {
                    // Create a new polyline object
                    var flightPath = new google.maps.Polyline({
                        path: polyline,
                        geodesic: true,
                        strokeColor: '#FF0000',
                        strokeOpacity: 1.0,
                        strokeWeight: 2
                    });

                    // Add the polyline to the map
                    flightPath.setMap(map);

                    // Get the last point of the polyline
                    var lastPoint = polyline[polyline.length - 1];

                    // Center the map on the last point
                    map.setCenter(new google.maps.LatLng(lastPoint.lat, lastPoint.lng));

                    // Create a new marker at the last point
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(lastPoint.lat, lastPoint.lng),
                        map: map,
                        title: 'Current Position'
                    });
                });
        };

        $(window).on('load',function(){
            if ($('#show-modal').val() == 1) {
                $('#approveModal').modal('show');
            } else if ($('#show-modal').val() == 2) {
                $('#rejectModal').modal('show');
            } else if ($('#show-modal').val() == 3) {
                $('#deleteModal').modal('show');
            };
        <?php if($quoteReq->status >= 8 && $quoteReq->status <= 11): ?>
            initMap();
        <?php endif; ?>
        });

        <?php if($quoteReq->status >= 8 && $quoteReq->status <= 11): ?>
        // setInterval(initMap, 5000);
        <?php endif; ?>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontendlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LOCALHOST\quickfreight\quickfreight\resources\views/customer/welcome.blade.php ENDPATH**/ ?>