<h3>Quick Freight Enterprise</h3>
<p>Hello. {{$driver_name}}!</p>
<p>In accordance with the contract with your company, we will provide you with additional information about the transport request assigned to you.</p>
<p>Please log in our site and check the quote.</p>
<a href = "{{route('login.driver')}}">Quick Freight Enterprise Inc Service</a>
<p>Email: {{$driver_email}}</p>
<p>Verify Code: {{$verify_code}}</p>
<br>
<small>QUICK FREIGHT ENTERPRISE</small><br>
<small>15867 SW 147th LN</small><br>
<small>MIAMI, FL 33196</small><br>
<small>+1 786 208 9900</small>
