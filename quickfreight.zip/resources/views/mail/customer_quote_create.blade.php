<h3>Congratulations!</h3>
<p>Your request is accepted by our service.</p>
<p>Please log in our service and confirm our quote.</p>
<a href = "{{route('login.customer')}}">Quick Freight Enterprise Inc Service</a>
<p>Email: {{$customer_email}}</p>
<p>Verify Code: {{$verify_code}}</p>
<br>
<small>QUICK FREIGHT ENTERPRISE</small><br>
<small>15867 SW 147th LN</small><br>
<small>MIAMI, FL 33196</small><br>
<small>+1 786 208 9900</small>